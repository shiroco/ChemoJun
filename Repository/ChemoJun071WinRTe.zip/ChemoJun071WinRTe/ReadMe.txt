About ChemoJun

------------------------------------------------------------
�yPreparation�z

Copy the directory "ChemoJun071WinRTe" into your hard disk.
Then operate as follows.

------------------------------------------------------------
�yStart�z

Double click "visual.bat" to start the ChemoJun.
ChemoJun launcher window appears on the top left of screen.

------------------------------------------------------------
�yQuit�z

Close the ChemoJun launcher window to quit.
"Really quit?" comes out, then press the button "Yes".

------------------------------------------------------------
